﻿var config = {
    host    : 'localhost',
    user    : 'hsdh',
    password: '12305',
    database: 'bandejapp'
};

exports.config = config;